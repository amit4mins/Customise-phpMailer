<?php

/**
 * This example shows settings to use when sending via Google's Gmail servers.
 */
//SMTP needs accurate times, and the PHP time zone MUST be set
//This should be done in your php.ini, but this is how to do it if you don't have access to that
date_default_timezone_set('Etc/UTC');

require __DIR__.'/../PHPMailerAutoload.php';

Class smtpMailer{
    protected $_mail;
    public $_recieverDetails=array();
    
    public function __construct() {
        //Create a new PHPMailer instance
        $this->_mail = new PHPMailer;

        //Tell PHPMailer to use SMTP
        $this->_mail->isSMTP();

        //Enable SMTP debugging
        // 0 = off (for production use)
        // 1 = client messages
        // 2 = client and server messages
        //$this->_mail->SMTPDebug = 2;

        //Ask for HTML-friendly debug output
        $this->_mail->Debugoutput = 'html';

        //Set the hostname of the mail server
        $this->_mail->Host = 'email-smtp.us-east-1.amazonaws.com';  //smtp.gmail.com
        // use
        // $this->_mail->Host = gethostbyname('smtp.gmail.com');
        // if your network does not support SMTP over IPv6
        //Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
        $this->_mail->Port =587 ;  //587

        //Set the encryption system to use - ssl (deprecated) or tls
        $this->_mail->SMTPSecure = 'tls';

        //Whether to use SMTP authentication
        $this->_mail->SMTPAuth = true;

        //Username to use for SMTP authentication - use full email address for gmail
        $this->_mail->Username = "AKIAJAYXNG45HXGHB7MA";  //unite.varian@gmail.com, test.mprog@gmail.com

        //Password to use for SMTP authentication
        $this->_mail->Password = 'AvXirO+7L4MTkKtq6b0ZfHI92TFQeMeV3uY30SUA2s+z';  //welcome@12, Te$t4mpr0g
        $this->_mail->From="webmaster@varian.com";  //support@varianunite.com
        $this->_mail->FromName="Varian Team";
        //Set who the message is to be sent from
        //$this->_mail->setFrom('support@varianunite.com', 'Varian Team',false);

        //Set who the message is to be sent to
        
        
    }
    
    public function FireMail($subject, $message){
        $this->_mail->addAddress($this->_recieverDetails['email_address'], $this->_recieverDetails['full_name']);
        //Set the subject line
        $this->_mail->Subject = $subject;
        //Read an HTML message body from an external file, convert referenced images to embedded,
        //convert HTML into a basic plain-text alternative body
        $this->_mail->msgHTML($message);

        //Replace the plain text body with one created manually
        $this->_mail->AltBody = 'OOPS, Email body is missing';

        //Attach an image file
        //$this->_mail->addAttachment('images/phpmailer_mini.png');
        //send the message, check for errors
        if ($this->_mail->send()) {
            return true;
        }
        return false;
    }

}
